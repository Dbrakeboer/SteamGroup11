# Steam Dashboard

Met behulp van het Steam Dashboard is het mogelijk om verschillende soorten data overzichtelijk in kaart te brengen.

## SteamGroup11: 

Daniel Brakeboer, 1782643 

Diederik Roovers, 1779316 

Jelle Hille, 1785577 

Giorgio Kersten, 1757974
 
## Usage

De gebruiker kan de file executen en zal dan gepresenteert worden met de GUI, in deze GUI staan straks meerdere keuzes om data te bekijken en te analyseren.