import json
import tkinter as tk 
from tkinter import ttk 
from tkinter import * 

def open_json():
    with open("steam.json", "r") as steam:
        data = json.load(steam)
        return data

def first_game():
    games_data = open_json()
    print(games_data[0]['name'])

def sorted_games():
    games_data = open_json()
    games_sorted = []
    counter = 0
    for i in games_data:
        games_sorted.append(games_data[counter]['name'])
        counter += 1
        
    gesorteerd = sorted(games_sorted)
    return gesorteerd

def show_dashboard():
    gesorteerd = sorted_games()
    root = Tk() 

    # This is the section of code which creates the main window 
    root.geometry('840x450') 
    root.configure(background='#1B2838') 
    root.title('Steam Dashboard') 

    # This is the section of code which creates the gamelabel 
    gamelabel = Label(root, text='Placeholder label', bg='#1B2838', fg='white', font=('arial', 12, 'normal'))
    gamelabel.place(x=338, y=210)
    updated_text = gesorteerd[0]
    gamelabel.configure(text = updated_text)

    root.mainloop()

show_dashboard()